﻿/////////////////////////
//製作者　名越大樹
//制作日　9月14日
//弾を生成するクラス
/////////////////////////

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class　BulletInstance : MonoBehaviour {

	
    public void InStance()
    {

    }
}
