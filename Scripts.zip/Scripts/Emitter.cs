﻿using UnityEngine;
using System.Collections;

public class Emitter : MonoBehaviour
{
    // Waveプレハブを格納する
    public GameObject[] waves;

    public GameObject warnning;
    public GameObject victory;
        

    // 現在のWave
    private int currentWave;

    // Managerコンポーネント
    private Manager manager;


	GameObject workobj2;
    GameObject workobj;

    public void ShowWord() {
        Debug.Log("gg");
        Destroy(workobj);
		Destroy (workobj2);
    }

      IEnumerator Start()
    {
        


        // Waveが存在しなければコルーチンを終了する
        if (waves.Length == 0)
        {
            yield break;
        }

        // Managerコンポーネントをシーン内から探して取得する
        manager = FindObjectOfType<Manager>();

        while (true)
        {

            // タイトル表示中は待機
            while (manager.IsPlaying() == false)
            {
                yield return new WaitForEndOfFrame();
            }

            // Waveを作成する
            GameObject g = (GameObject)Instantiate(waves[currentWave], transform.position, Quaternion.identity);

            // WaveをEmitterの子要素にする
            g.transform.parent = transform;

            //boss
            if (currentWave == 3)
            {



                //transform.position = new Vector3(0, 2.5f, 0);
                workobj = Instantiate(warnning, new Vector3(0f, 2f, 0f), Quaternion.identity);
                Invoke("ShowWord", 2);


            }
                



                while (g.transform.childCount != 0)
            {
                yield return new WaitForEndOfFrame();
            }

            // Waveの削除
            Destroy(g);

            // 格納されているWaveを全て実行したらcurrentWaveを0にする（最初から -> ループ）
            if (waves.Length <= ++currentWave)
            {


				workobj2 = Instantiate(victory, new Vector3(0f, 2f, 0f), Quaternion.identity);
				Invoke("ShowWord", 2);
				manager.GameOver();
                


            }

        }
    }
}