﻿using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour
{


    // 弾のPrefab
    public GameObject bullet;


    // ヒットポイント
    public int hp = 1;
    // Spaceshipコンポーネント

    // スコアのポイント
    public int point = 100;

      public int type = 1;
    Player target;

    Spaceship spaceship;

    IEnumerator Start()
    {

        target = FindObjectOfType<Player>();
        // Spaceshipコンポーネントを取得
        spaceship = GetComponent<Spaceship>();

        // ローカル座標のY軸のマイナス方向に移動する

        if (type == 4)
        {
            Move(target.transform.position - transform.position);
        }


        else 
        {
           
            
                Move(transform.up * -1);
            
         }



        // canShotがfalseの場合、ここでコルーチンを終了させる
        if (spaceship.canShot == false)
        {
            yield break;
        }

        while (true)
        {

            // 子要素を全て取得する
            for (int i = 0; i < transform.childCount; i++)
            {

                Transform shotPosition = transform.GetChild(i);

                // ShotPositionの位置/角度で弾を撃つ
				if (type == 0 || type == 4) {
					Instantiate (bullet, shotPosition.position, shotPosition.rotation);
				}
                else if (type == 1) {

					float baseDirection = GetAim ();
					int count = 0;

                    if (transform.position.y < 2f)
                    {
                        transform.position = new Vector3(0f, 2f, 0f);
                        spaceship.speed = 0;
                    }

                    // 檻の中心角度を設定。最初の自キャラ角度を中心として＋３０度～－３０度の範囲をゆらゆら動かす
                    float dir = (baseDirection + Mathf.Sin (count * 1 * Mathf.Deg2Rad) * 30.0f);
					//Debug.Log (dir);
					// 偶数弾を撃つ感じで、自キャラ角度を外して上下３本づつ０．０５秒毎に弾発射
					for (int index = -16; index < 0; index= index+4) {

                            
						Instantiate (bullet, transform.position, Quaternion.Euler (0.0f, 0.0f, dir + index * 10 ));

					}
                    
                    count++;
                    
				} else if (type == 2) {

                   
                    float smooth = 2000f;
					Vector2 dir = target.transform.position - transform.position;

                    transform.Rotate(dir, Time.deltaTime * smooth, Space.World);

                    Instantiate (bullet, transform.position, transform.rotation);
                   // Debug.Log(transform.rotation);
				}
                else if (type == 3)
                {
                    if (transform.position.y < 2f)
                    {
                        transform.position = new Vector3(0f, 2f, 0f);
                        spaceship.speed = 0;
                    }
                    // transform.position = new Vector3(0f, 2f, 0f);
                    Instantiate(bullet, transform.position, Quaternion.Euler(0.0f, 0.0f, Random.Range(130,230)));
                   // Debug.Log(transform.rotation);
                }
                else if (type == 5)
                {

                    

                    
                        transform.position = new Vector3(0f, 2f, 0f);
                        spaceship.speed = 0;
                    

                  
                    for (int index = -90; index < 90; index=index+9
                     )
                    {


                        Instantiate(bullet, transform.position, Quaternion.Euler(0.0f, 0.0f, index*2 ));

                    }

                    

                }


            }
                // shotDelay秒待つ
                yield return new WaitForSeconds(spaceship.shotDelay);
            }
        
    }

    public void Move(Vector2 direction)
    {

       
                GetComponent<Rigidbody2D>().velocity = direction * spaceship.speed;
         


    }

        public float GetAim()
        {
            float dx = target.transform.position.x - transform.position.x;
            float dy = target.transform.position.y - transform.position.y;
       // Debug.Log(Mathf.Atan2(dy, dx) * Mathf.Rad2Deg);
        return Mathf.Atan2(dy, dx) * Mathf.Rad2Deg;
            
        }

        void OnTriggerEnter2D(Collider2D c)
    {
        // レイヤー名を取得
        string layerName = LayerMask.LayerToName(c.gameObject.layer);

        // レイヤー名がBullet (Player)以外の時は何も行わない
        if (layerName != "Bullet (Player)") return;


        // PlayerBulletのTransformを取得
        Transform playerBulletTransform = c.transform.parent;

    

        // Bulletコンポーネントを取得
        Bullet bullet = playerBulletTransform.GetComponent<Bullet>();


        // ヒットポイントを減らす
        hp = hp - bullet.power;

        // 弾の削除
        Destroy(c.gameObject);
        if (hp <= 0) {

            // スコアコンポーネントを取得してポイントを追加
            FindObjectOfType<Score>().AddPoint(point);
            // 爆発
            spaceship.Explosion();
		
		// エネミーの削除
		Destroy(gameObject);
        }
       // else
       // {
          //  spaceship.GetAnimator().SetTrigger("Damage");
       // }
    }
}